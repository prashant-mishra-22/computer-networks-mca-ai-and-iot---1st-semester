import socket
import threading

HEADER=64
FORMAT='utf-8'
DISCONNECT_MESSAGE="!DISCONNECT"
PORT=5050
SERVER=socket.gethostbyname(socket.gethostname())
ADDR=(SERVER,PORT)

server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(ADDR)

def handle_client(conn,addr):
    print(f"\n[NEW CONNECTION] {addr} is connected.")
    connected=True
    sl=[]
    while connected:
        msg_length=conn.recv(HEADER).decode(FORMAT)
        msg_length=int(msg_length)
        msg=conn.recv(msg_length).decode(FORMAT)
        if msg == DISCONNECT_MESSAGE:
            connected=False
            conn.send("server is disconnected".encode(FORMAT))
        elif msg == "output" :
            output="output is : "+str(int(sl[0])+int(sl[1]))
            conn.send(output.encode(FORMAT))
        else :
            sl.append(msg)
            conn.send(f"number {msg} recieved on server".encode(FORMAT))
            
        print(f"\n[{addr}] send a message : {msg}")
    conn.close()


def start():
    server.listen()
    print(f"\n[LISTENING] server is listening on {ADDR}")
    while True:
        conn,addr=server.accept()
        thread=threading.Thread(target=handle_client,args=(conn,addr))
        thread.start()
        print(f"\n[ACTIVE CONNECTIONS ]{threading.active_count()-1}")

    

print(f"\n[STARTING] server is starting ...")
start()