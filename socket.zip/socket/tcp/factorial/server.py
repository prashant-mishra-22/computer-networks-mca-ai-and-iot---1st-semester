import socket 
import threading

HEADER=64
FORMAT='utf-8'
DISCONNECT_MESSAGE="!DISCONNECT"

PORT=5050
SERVER=socket.gethostbyname(socket.gethostname())
ADDR=(SERVER,PORT)

server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(ADDR)

def factorial(num) :
    fact=1
    while num>0 :
        fact=fact*num
        num=num-1
    return fact
    

def handle_client(conn,addr) :
    print(f"[ NEW CONNECTION ] {addr} is connected to server ")
    connected = True
    while connected :
        msg_length=conn.recv(HEADER).decode(FORMAT)
        msg_length=int(msg_length)
        msg=conn.recv(msg_length).decode(FORMAT)
        if msg == DISCONNECT_MESSAGE :
            connected = False 
            print(f"[ {addr} ] sent a request to disconnect ")
            conn.send("\nserver is disconnected ".encode(FORMAT))
        else :
            print(f"\n[ {addr} ] send a number : {msg}")
            if int(msg)<0 :
                conn.send("\ninvalid input".encode(FORMAT))
            else :
                output=f"\nfactorial of {msg} is : "+str(factorial(int(msg)))
                conn.send(output.encode(FORMAT))
    
    conn.close()


def start() :
    server.listen()
    print(f"\n[ LISTENING ] server is listening on {ADDR} ")
    while True :
        conn,addr=server.accept()
        thread=threading.Thread(target=handle_client,args=(conn,addr))
        thread.start()
        print(f"\n[ ACTIVE CONNECTIONS ] total active connections : {threading.active_count()-1}")





print(f"\n[ STARTING ] server is starting")
start()