import socket
import threading

HEADER=64
FORMAT='utf-8'
DISCONNECT_MESSAGE="!DISCONNECT"
PORT=5050
SERVER=socket.gethostbyname(socket.gethostname())
ADDR=(SERVER,PORT)

server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(ADDR)

def handle_client(conn,addr):
    print(f"\n[NEW CONNECTION] {addr} is connected.")
    connected=True
    sl=[]
    while connected:
        msg_length=conn.recv(HEADER).decode(FORMAT)
        msg_length=int(msg_length)
        msg=conn.recv(msg_length).decode(FORMAT)
        if msg == DISCONNECT_MESSAGE:
            connected=False
            print(f"\n[{addr}] send a request to : {msg}")
            conn.send("\nserver is disconnected".encode(FORMAT))
        elif msg == "addition" :
            print(f"\n[{addr}] send a request to perform : {msg}")
            output=f"\n{sl[0]} + {sl[1]} = : "+str(int(sl[0])+int(sl[1]))
            conn.send(output.encode(FORMAT))
        elif msg == "substraction" :
            print(f"\n[{addr}] send a request to perform : {msg}")
            output=f"\n{sl[0]} - {sl[1]} = : "+str(int(sl[0])-int(sl[1]))
            conn.send(output.encode(FORMAT))
        elif msg == "multiplication" :
            print(f"\n[{addr}] send a request to perform : {msg}")
            output=f"\n{sl[0]} * {sl[1]} = : "+str(int(sl[0])*int(sl[1]))
            conn.send(output.encode(FORMAT))
        elif msg == "division" :
            print(f"\n[{addr}] send a request to perform : {msg}")
            output=f"\n{sl[0]} / {sl[1]} = : "+str(int(sl[0])/int(sl[1]))
            conn.send(output.encode(FORMAT))
        elif msg == "modulus" :
            print(f"\n[{addr}] send a request to perform : {msg}")
            output=f"\n{sl[0]} % {sl[1]} = : "+str(int(sl[0])%int(sl[1]))
            conn.send(output.encode(FORMAT))
        else :
            print(f"\n[{addr}] send a number : {msg}")
            sl.append(msg)
            conn.send(f"number {msg} recieved on server".encode(FORMAT))       
    conn.close()


def start():
    server.listen()
    print(f"\n[LISTENING] server is listening on {ADDR}")
    while True:
        conn,addr=server.accept()
        thread=threading.Thread(target=handle_client,args=(conn,addr))
        thread.start()
        print(f"\n[ACTIVE CONNECTIONS ]{threading.active_count()-1}")

    

print(f"\n[STARTING] server is starting ...")
start()