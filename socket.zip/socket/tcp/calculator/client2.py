import socket

HEADER=64
FORMAT='utf-8'
DISCONNECT_MESSAGE="!DISCONNECT"

PORT=5050
SERVER="192.168.57.96"
ADDR=(SERVER,PORT)

client=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
client.connect(ADDR)

def send(msg):
    message=msg.encode(FORMAT)
    msg_length=len(message)
    send_length=str(msg_length).encode(FORMAT)
    send_length += b' ' * (HEADER-len(send_length))
    client.send(send_length)
    client.send(message)
    print("\n")
    print(client.recv(2048).decode(FORMAT))

a=input("\nenter first number : ")
send(a)
input()

b=input("nenter second number : ")
send(b)
input()

print("\n1:addition\t2:substraction\t3:multiplication\n4:division\t5:modulus\n")
c=int(input("enter your choice : "))

match c :
    case 1 :
        send("addition")
    case 2 :
        send("substraction")
    case 3 :
        send("multiplication")
    case 4 :
        send("division")
    case 5 :
        send("modulus")
    case _:
        print("\nwrong input")


input("\npress enter to disconnect from server ")
send(DISCONNECT_MESSAGE)