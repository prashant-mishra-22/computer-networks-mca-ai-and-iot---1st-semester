import socket 
import threading 

HEADER=2048
FORMAT='utf-8'

PORT=8000
SERVER=socket.gethostbyname(socket.gethostname())
ADDR=(SERVER,PORT)

server=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
server.bind(ADDR)

print(f"\n[ STARTING ] server is starting on {ADDR} \n")

sl={}

def handle_client(data,addr) :
    msg=data.decode(FORMAT)
    if msg=="output":
        print(f"\n{addr} wants the result \n")
        output=int(sl[addr][0])+int(sl[addr][1])
        responce=f"\n{sl[addr][0]}+{sl[addr][1]}={output}".encode(FORMAT)
        server.sendto(responce,addr)
        del sl[addr]
    else:
        print(f"\n{addr} send a number : {msg}\n")
        if addr in sl :
            sl[addr].append(msg)
        else :
            sl[addr]=[msg]
        responce= f"\n {msg} recieved on server \n".encode(FORMAT)
        server.sendto(responce,addr)

while True:
    data,addr=server.recvfrom(HEADER)
    thread=threading.Thread(target=handle_client,args=(data,addr))
    thread.start()



