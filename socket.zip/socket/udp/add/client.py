import socket 

HEADER=2048
FORMAT='utf-8'

PORT=8000
SERVER="192.168.128.96"
ADDR=(SERVER,PORT)

client=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

def send(msg):
    message=msg.encode(FORMAT)
    client.sendto(message,ADDR)
    responce , _ = client.recvfrom(HEADER)
    print(responce.decode(FORMAT))
e1=input("\nenter first number : ")
send(e1)
e2=input("\nenter second number : ")
send(e2)
input("\npress any key to get output \n")
send("output")
input("\npress any key to exit ")
client.close()
    