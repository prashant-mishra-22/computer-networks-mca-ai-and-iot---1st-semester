import socket 

HEADER=2048
FORMAT='utf-8'

PORT=8000
SERVER="192.168.128.96"
ADDR=(SERVER,PORT)

client=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

def send(msg):
    message=msg.encode(FORMAT)
    client.sendto(message,ADDR)
    responce , _ = client.recvfrom(HEADER)
    print(responce.decode(FORMAT))
c=1
while c==1:
    ch=input("enter a charcater to get its ascii value : ")
    send(ch)
    c=int(input("enter 0:exit 1:continue ==> "))

client.close()
    