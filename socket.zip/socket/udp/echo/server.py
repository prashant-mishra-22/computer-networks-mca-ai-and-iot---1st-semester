import socket 
import threading 

HEADER=2048
FORMAT='utf-8'

PORT=8000
SERVER=socket.gethostbyname(socket.gethostname())
ADDR=(SERVER,PORT)

server=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
server.bind(ADDR)

print(f"\n[ STARTING ] server is starting on {ADDR} \n")

def handle_client(data,addr) :
    msg=data.decode(FORMAT)
    print(f"\n{addr} : {msg}\n")
    responce= f"\n {msg} \n".encode(FORMAT)
    server.sendto(responce,addr)

while True:
    data,addr=server.recvfrom(HEADER)
    thread=threading.Thread(target=handle_client,args=(data,addr))
    thread.start()



