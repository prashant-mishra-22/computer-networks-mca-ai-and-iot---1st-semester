import socket 

HEADER=2048
FORMAT='utf-8'

PORT=8000
SERVER="10.1.14.181"
ADDR=(SERVER,PORT)

client=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

def send(msg):
    message=msg.encode(FORMAT)
    client.sendto(message,ADDR)
    responce , _ = client.recvfrom(HEADER)
    print(responce.decode(FORMAT))

send("hello")
input()
send("hi i am a client")
input()
send("i am talking to server ")
input()
send("this is a echo program")
input()
send("this program is using client server architecture using udp")
input("\npress any key to exit ")
client.close()
    